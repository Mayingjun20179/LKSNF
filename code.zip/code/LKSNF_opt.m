%%%%%% Predict connection scores using all known connections as training sets
function score = LKSNF_opt()
str = load('knowndiseasemirnainteraction.txt');
nd = max(str(:,2)); nm = max(str(:,1)); [pp,~] = size(str);
% FS:the functional similarity between m(i) and m(j)
% FSP:Functional similarity weighting matrix
% SS:the semantic similarity between d(i) and d(j).
% SSP:semantic similarity weighting matrix
FS = load('functional similarity matrix.txt');  
FSP = load('Functional similarity weighting matrix.txt');             
SS1 = load('disease semantic similarity matrix 1.txt');
SS2 = load('disease semantic similarity matrix 2.txt');
SS = (SS1+SS2)/2;
SSP = load('disease semantic similarity weighting matrix1.txt');
%interaction: adajency matrix for the disease-miRNA association network
%interaction(i,j)=1 means miRNA j is related to disease i
interaction = zeros(nd,nm);  
for i = 1:pp
    interaction(str(i,2),str(i,1)) = 1;
end
seed = 1;
interaction_matrix = interaction;

% miRNA�� interaction profile  
num = 0.3;  % Number of neighbors
ar = 0.1;   % Propagation parameter
neighbor_num = floor(num*nm);           
KSNS_SmC = KSNS_opt(interaction_matrix',neighbor_num);  
S_M = SNF({FS.*FSP,KSNS_SmC},5,5,1);        S_M = matrix_normalize(S_M);
neighbor_num = floor(num*nd);   
KSNS_SdC = KSNS_opt(interaction_matrix,neighbor_num);  
S_D = SNF({SS.*SSP,KSNS_SdC},5,5,1);        S_D = matrix_normalize(S_D);
Rt_M =calculate_labels(S_M,interaction_matrix',ar)';
Rt_D =calculate_labels(S_D,interaction_matrix,ar);
score = (Rt_M+Rt_D)/2; 
end 

function W = matrix_normalize(W)

W(isnan(W))=0;
for i=1:size(W,1)
    W(i,i) = 0;
end
for round=1:20
    D=diag(sum(W,2));
    D1=pinv(sqrt(D));
    W=D1*W*D1;
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   KSNS
function S = KSNS_opt(X,neighbor_num)
feature_matrix = X;
nearst_neighbor_matrix = KSNS_neighbors(feature_matrix,neighbor_num);
S = jisuanW_opt(feature_matrix,nearst_neighbor_matrix);
end

function nearst_neighbor_matrix=KSNS_neighbors(feature_matrix,neighbor_num)
%%%%nearst_neighbor_matrix��  represent Neighbor matrix
  X = feature_matrix;
  N = size(X,1);
  D = pdist2(X,X,'euclidean');  
  D = D+diag(inf*ones(1,N));
  [~, si]=sort(D,2,'ascend');
  nearst_neighbor_matrix=zeros(N,N);
  index=si(:,1:neighbor_num);
  for i=1:N
      nearst_neighbor_matrix(i,index(i,:))=1;     
  end
end

%The iterative process of this algorithm
function [W,objv] = jisuanW_opt(feature_matrix,nearst_neighbor_matrix)
lata1=4;  lata2=1;
X=feature_matrix';  % each column of X represents a sample, and each behavior is an indicator
[~,N] = size(X);    % N represents the number of samples
C = nearst_neighbor_matrix';
rand('state',1);
W = rand(N,N);
W = W./repmat(sum(W),N,1);
G  =jisuan_Kel(X);
G(isnan(G))=0;
G = G/max(G(:));
WC1 = W'*G*W-2*W*G+G;
WC = sum(diag(WC1))/2;
wucha = WC + norm(W.*(1-C),'fro')^2*lata1/2 +  norm(W,'fro')^2*lata2/2;
objv = wucha;
jingdu = 0.0001;
error = jingdu*(1+lata1+lata2);   %Iteration error threshold
we = 1;      %Initial value of error
gen=1;
while  gen<100 && we>error
    %gen
    FZ = G+lata1*C.*W;
    FM = G*W+lata1*W+lata2*W;    
    W = FZ./(FM+eps).*W;  
    WC1 = W'*G*W-2*W*G+G;
    WC = sum(diag(WC1))/2;
    wucha = WC + norm(W.*(1-C),'fro')^2*lata1/2 +  norm(W,'fro')^2*lata2/2;    
    we = abs(wucha-objv(end));
    objv = [objv,wucha];
    gen = gen+1;
end
W=W'; 
W = matrix_normalize(W);
end

function W = matrix_normalize(W)
W(isnan(W))=0;
for i=1:size(W,1)
    W(i,i) = 0;
end
for round=1:20
    D=diag(sum(W,2));
    D1=pinv(sqrt(D));
    W=D1*W*D1;
end
end

function K  =jisuan_Kel(X)
%X Columns represent samples, and rows represent features
X = X';
sA = (sum(X.^2, 2));
sB = (sum(X.^2, 2));
K = exp(bsxfun(@minus,bsxfun(@minus,2*X*X', sA), sB')/mean(sA));
end




function [W]=SNF(Wall,K,t,ALPHA)
%Reference from B. Wang "Similarity network fusion for aggregating data types on a genomic scale," Nature methods, vol 11, 2014, pp. 333.
%%%%Wall: Similar matrix set
%%%%K
%%%%t
%%%%ALPHA

if nargin < 2
    K = 20;
end
if nargin < 3
    t = 20;
end

if nargin < 4
    ALPHA = 1;
end

C = length(Wall);
[m,n]=size(Wall{1});
for i = 1 : C
    Wall{i} = Wall{i}./repmat(sum(Wall{i},2),1,n);  %%��֤ÿһ�еĺ�Ϊ1
    Wall{i} = (Wall{i} + Wall{i}')/2; %�Գ�
end

for i = 1 : C
    newW{i} = FindDominateSet(Wall{i},round(K));
end

Wsum = zeros(m,n);
for i = 1 : C
    Wsum = Wsum + Wall{i};
end
for ITER=1:t
    for i = 1 : C
        %Wall0{i}=newW{i}*(0.95*(Wsum - Wall{i})/(C-1)+0.05*eye(length(Wsum)))*newW{i}';
        Wall0{i}=newW{i}*(Wsum - Wall{i})*newW{i}'/(C-1);
    end
    for i = 1 : C
        Wall{i} = BOnormalized(Wall0{i},ALPHA);  %%
    end
    Wsum = zeros(m,n);
    for i = 1 : C
        Wsum = Wsum + Wall{i};
    end
%     
end

W = Wsum/C;
W = W./repmat(sum(W,2),1,n);
W = (W +W'+eye(n))/2;
end

function W = BOnormalized(W,ALPHA)
if nargin < 2
    ALPHA = 1;
end
W = W+ALPHA*eye(length(W));   
W = (W +W')/2;
end

function newW = FindDominateSet(W,K)
%%��֧�伯
[m,n]=size(W);
[~,IW1] = sort(W,2,'descend');  %��������
newW=zeros(m,n);
temp=repmat((1:n)',1,K);
I1=(IW1(:,1:K)-1)*m+temp;
newW(I1(:))=W(I1(:));
newW=newW./repmat(sum(newW,2),1,n);
clear IW1;
clear IW2;
clear temp;
end





